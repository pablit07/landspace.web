import React from 'react';

export default class IndexPage extends React.Component {
	render() {
		return (
			<h1>404 Not Found</h1>
		);
	};
}