window.mockJsonPCallback({
    "foo": "bar"
});
